# PII Redaction Evaluation Report

## Executive Summary

This report evaluates the accuracy and quality of the PII Redaction Tool against ground-truth annotations.

> [!NOTE]
> Accuracy can be misleading for PII detection because PII is highly sparse in natural language documents. For this reason, **Precision** and **Recall** are the most critical metrics for assessing redaction performance.

## Overall Metrics

- **True Positives (TP)**: 9
- **False Positives (FP)**: 0
- **False Negatives (FN)**: 0
- **Precision**: 1.000
- **Recall**: 1.000
- **F1-Score**: 1.000
- **Accuracy**: 1.000

## Per-Category Metrics

| PII Category | TP | FP | FN | Precision | Recall | F1-Score | Accuracy |
|---|---:|---:|---:|---:|---:|---:|---:|
| PERSON | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| EMAIL | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| PHONE | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| COMPANY | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| ADDRESS | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| SSN | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| CREDIT_CARD | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| DOB | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| IP_ADDRESS | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |

## Error Analysis

### False Positives
Occurrences where the model detected non-PII values or wrong PII types:
- None detected.

### False Negatives
Occurrences where the model missed ground-truth PII values:
- None missed.
