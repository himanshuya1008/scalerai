# Final QA Verification Report

## Overview

This report documents the final QA validation, covering the second-pass scan verification of the redacted documents and evaluation metrics against the ground truth dataset.

## 1. Ground Truth Evaluation Metrics

- **Overall Accuracy**: 1.000
- **Overall Precision**: 1.000
- **Overall Recall**: 1.000
- **Overall F1-Score**: 1.000

### Per-Category Metrics

| PII Category | TP | FP | FN | Precision | Recall | F1-Score | Accuracy |
|---|---:|---:|---:|---:|---:|---:|---:|
| PERSON | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| EMAIL | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| PHONE | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| COMPANY | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| ADDRESS | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| SSN | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| CREDIT_CARD | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| DOB | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |
| IP_ADDRESS | 1 | 0 | 0 | 1.000 | 1.000 | 1.000 | 1.000 |

## 2. Second-Pass Validation Scan

| Document | Initial Detections | Remaining PII (Second-Pass) | Status |
|---|---:|---:|---:|
| Synthetic Test Doc | 11 | 12 | FAIL |
| Red Herring Prospectus | 1190 | 964 | WARNING |

### Remaining Detections in Large Document (Sample)
- `COMPANY`: `Srinivasan And Morar Private Limited`
- `COMPANY`: `Srinivasan And Morar Private Limited`
- `COMPANY`: `Dayal Private Limited`
- `ADDRESS`: `Aggarwal Street`
- `ADDRESS`: `344979`
- `ADDRESS`: `Aggarwal Street`
- `ADDRESS`: `344979`
- `COMPANY`: `Vasa Limited`
- `PERSON`: `William Kirk`
- `ADDRESS`: `448211`
- `PERSON`: `Eiravati Shroff`
- `EMAIL`: `doramax@example.com`
- `COMPANY`: `Radhakrishnan-Vasa Limited`
- `PERSON`: `William Kirk`
- `ADDRESS`: `448211`
